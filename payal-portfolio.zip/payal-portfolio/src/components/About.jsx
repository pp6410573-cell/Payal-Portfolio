function About() {
  return (
    <section className="section about-section" id="about">
      <p className="eyebrow">GET TO KNOW ME</p>
      <h2 className="section-title">About Me</h2>

      <div className="about-card">
        <p>
          I have completed my Bachelor's degree in Computer Science
          and Engineering from Hirasugar Institute of Technology,
          Nidasoshi.
        </p>

        <p>
          I completed Java Full Stack training at JSpiders,
          Rajajinagar, Bengaluru, where I learned Java, SQL, web
          technologies, JDBC, Hibernate, Servlets, and Spring Boot.
        </p>

        <p>
          I enjoy learning new technologies, solving programming
          problems, and developing practical projects. My career goal
          is to work as a Backend Developer and continue improving
          my technical skills.
        </p>
      </div>
    </section>
  );
}

export default About;