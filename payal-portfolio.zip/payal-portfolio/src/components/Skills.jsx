const skills = [
  "Java",
  "Spring Boot",
  "Spring MVC",
  "Hibernate",
  "JPA",
  "JDBC",
  "SQL",
  "MySQL",
  "HTML",
  "CSS",
  "JavaScript",
  "React",
  "Git",
  "GitHub",
];

function Skills() {
  return (
    <section className="section" id="skills">
      <p className="eyebrow">WHAT I WORK WITH</p>
      <h2 className="section-title">My Skills</h2>

      <p className="section-description">
        Technologies I have learned and used while practicing
        and developing projects.
      </p>

      <div className="skills-grid">
        {skills.map((skill) => (
          <div className="skill-card" key={skill}>
            {skill}
          </div>
        ))}
      </div>
    </section>
  );
}

export default Skills;