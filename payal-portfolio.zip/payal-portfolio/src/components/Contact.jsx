function Contact() {
  return (
    <section className="section contact-section" id="contact">
      <p className="eyebrow">LET'S CONNECT</p>
      <h2 className="section-title">Contact Me</h2>

      <p className="contact-description">
        I'm interested in fresher opportunities in Java development
        and backend development. Feel free to connect with me.
      </p>

      <div className="contact-links">
        <a
          className="button primary-button"
          href="mailto:your-email@example.com"
        >
          Email Me
        </a>

        <a
          className="button secondary-button"
          href="https://www.linkedin.com/in/payal-patil-2071a0358/"
          target="_blank"
          rel="noreferrer"
        >
          LinkedIn Profile
        </a>
      </div>
    </section>
  );
}

export default Contact;