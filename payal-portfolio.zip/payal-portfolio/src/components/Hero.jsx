function Hero() {
  return (
    <section className="hero section" id="home">
      <div className="hero-content">
        <p className="eyebrow">JAVA FULL STACK DEVELOPER</p>

        <h1>
          Hi, I'm <span>Payal Patil</span>
        </h1>

        <h2>Java Developer | Backend Development Enthusiast</h2>

        <p className="hero-description">
          I'm a Computer Science and Engineering graduate interested in
          building reliable web applications using Java, Spring Boot,
          databases, and modern web technologies.
        </p>

        <div className="hero-buttons">
          <a className="button primary-button" href="#projects">
            View My Projects
          </a>

          <a className="button secondary-button" href="#contact">
            Contact Me
          </a>
        </div>

        <p className="location">📍 Belagavi, Karnataka, India</p>
      </div>

      <div className="profile-card">
        <div className="profile-circle">PP</div>
        <h3>Payal Patil</h3>
        <p>Java Full Stack Developer</p>

        <div className="profile-divider"></div>

        <p>Java · Spring Boot · MySQL · React</p>
      </div>
    </section>
  );
}

export default Hero;