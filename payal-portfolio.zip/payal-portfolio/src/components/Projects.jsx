const projects = [
  {
    title: "BookMyTicket",
    category: "Java Full Stack Project",
    description:
      "A movie ticket booking application where users can browse movies, select shows and seats, and book tickets. It includes movie and show management for administrators.",
    technologies: [
      "Java",
      "Spring Boot",
      "MySQL",
      "Thymeleaf",
    ],
  },
  {
    title: "Socio-X",
    category: "AI-Powered Social Media Assistant",
    description:
      "A social media assistant designed to help users generate captions, hashtags, and descriptions using AI, with social media management features.",
    technologies: [
      "React",
      "Node.js",
      "MongoDB",
      "Python",
      "AI",
    ],
  },
  {
    title: "MechMeetCar",
    category: "Vehicle Service Platform",
    description:
      "A platform connecting vehicle owners with mechanics for vehicle services. It is designed to support service booking and make finding mechanics more convenient.",
    technologies: [
      "Web Development",
      "MySQL",
      "REST APIs",
    ],
  },
];

function Projects() {
  return (
    <section className="section projects-section" id="projects">
      <p className="eyebrow">SOME THINGS I HAVE BUILT</p>
      <h2 className="section-title">My Projects</h2>

      <p className="section-description">
        Practical projects that helped me learn application
        development and understand real-world requirements.
      </p>

      <div className="projects-grid">
        {projects.map((project) => (
          <article className="project-card" key={project.title}>
            <div className="project-number">
              PROJECT / {String(projects.indexOf(project) + 1).padStart(2, "0")}
            </div>

            <h3>{project.title}</h3>

            <p className="project-category">{project.category}</p>

            <p className="project-description">
              {project.description}
            </p>

            <div className="tech-list">
              {project.technologies.map((technology) => (
                <span className="tech-tag" key={technology}>
                  {technology}
                </span>
              ))}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}

export default Projects;