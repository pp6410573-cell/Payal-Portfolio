function Footer() {
  return (
    <footer className="footer">
      <p>
        © {new Date().getFullYear()} Payal Patil. Built with React.
      </p>
    </footer>
  );
}

export default Footer;